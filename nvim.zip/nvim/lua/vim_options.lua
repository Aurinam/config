vim.cmd("set expandtab")
vim.cmd("set tabstop=4")
vim.cmd("set softtabstop=4")
vim.cmd("set shiftwidth=4")
vim.cmd("set number")
vim.cmd("set relativenumber")
vim.g.mapleader = " "
vim.g.background = "light"

-- Setting the colour of line number 

vim.cmd [[
  highlight LineNr guifg=#505ac7 guibg=NONE,
  highlight CursorLineNr guifg=#c75050 guibg=NONE
]]


-- For popup menus (like completion)
vim.cmd("highlight Pmenu guibg=#1E1E2E")  -- Choose a solid color (adjust to your liking)
vim.cmd("highlight PmenuSbar guibg=#1E1E2E")
vim.cmd("highlight PmenuSel guibg=#3A3A4E")  -- Selected item in popup menu

-- For floating windows
vim.cmd("highlight FloatBorder guibg=#1E1E2E")
vim.cmd("highlight NormalFloat guibg=#1E1E2E")

vim.opt.swapfile = false
vim.opt.termguicolors = true
-- vim.opt.clipboard = "unnamedplus"

-- Navigate vim panes better
vim.keymap.set('n', '<c-k>', ':wincmd k<CR>')
vim.keymap.set('n', '<c-j>', ':wincmd j<CR>')
vim.keymap.set('n', '<c-h>', ':wincmd h<CR>')
vim.keymap.set('n', '<c-l>', ':wincmd l<CR>')

vim.keymap.set('n', '<leader>h', ':nohlsearch<CR>')
vim.wo.number = true

-- Map 'jk' to escape in insert and visual modes
vim.keymap.set({'i', 'v'}, 'jk', '<Esc>')
vim.keymap.set({'i', 'v', 'n'}, '||', '<Esc>:')
vim.keymap.set({'i', 'v', 'n'}, '<C-<CR>>', '<Esc>o')
