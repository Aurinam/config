return {
    "nvimtools/none-ls.nvim",
    dependencies = {
        "nvimtools/none-ls-extras.nvim",
    },
    config = function()
        local null_ls = require("null-ls")
        null_ls.setup({
            sources = {
                null_ls.builtins.formatting.stylua,
                -- null_ls.builtins.formatting.prettier,
                -- null_ls.builtins.diagnostics.eslint_d,
                -- null_ls.builtins.formatting.ast-grep,
                -- null_ls.builtins.diagnostics.erb_lint,
                -- null_ls.builtins.diagnostics.ast-grep,

                -- C/C++
                null_ls.builtins.formatting.clang_format,
                require("none-ls.diagnostics.cpplint"), -- by this systax i am using a older lagasy support server to use cpplintyf
                -- none-ls.diagnostics.cpplint,

                -- Python
                null_ls.builtins.formatting.black,
                null_ls.builtins.formatting.isort,

                -- JavaScript/HTML/CSS
                null_ls.builtins.formatting.prettier,
                require("none-ls.diagnostics.eslint"),  -- by this systax i am using a older lagasy support server to use cpplinty
                null_ls.builtins.diagnostics.stylelint,
                -- null_ls.builtins.diagnostics.eslint,

            },
        })

        vim.keymap.set("n", "<leader>ii", vim.lsp.buf.format, {})
    end,
}
