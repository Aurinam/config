return {
	{
		"catppuccin/nvim",
		lazy = false,
		name = "catppuccin",
		priority = 1000,
		config = function()
			require("catppuccin").setup({
				transparent_background = true,
				flavour = "mocha",
				highlight_overrides = {
					all = function(colors)
						return {
							-- Popup menu background and selection highlight
							Pmenu = { bg = "#57275B", fg = colors.text }, -- Background color for popup
							PmenuSel = { bg = colors.surface2, fg = colors.lavender }, -- Color for selected item
							-- Optional: scrollbar or borders for popups
							PmenuSbar = { bg = colors.surface1 },
							PmenuThumb = { bg = colors.surface2 },
							FloatBorder = { bg = colors.base, fg = colors.lavender }, -- Borders for floating windows
							NormalFloat = { bg = colors.surface1 }, -- Background for floating windows
							-- Line number colors
							LineNr = { fg = "#9399b2" }, -- Color for regular line numbers
							CursorLineNr = { fg = "#ffffff", bold = true }, -- Highlight for current line number
						}
					end,
				},
			})

			-- Apply the colorscheme
			vim.cmd([[colorscheme catppuccin]])
		end,
	},
}
